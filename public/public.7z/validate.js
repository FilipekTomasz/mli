document.getElementById('validate').addEventListener('click', validate)


function validate(){
    
}